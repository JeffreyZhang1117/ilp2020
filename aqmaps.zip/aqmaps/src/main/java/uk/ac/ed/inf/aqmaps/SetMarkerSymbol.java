package uk.ac.ed.inf.aqmaps;

public class SetMarkerSymbol {
	
	/**
	 * static function to find the makersymbol
	 * @param reading
	 * @param battery
	 * @return string of markersymbol
	 */
	
	public static String Setmarkersymbol(String reading,Double battery) {
		String Markersymbol = "no symbol";
		if (reading.equals("NaN") || reading.equals("null")) {
			Markersymbol = "cross";
			return Markersymbol;
		}
		Double x = Double.parseDouble(reading);
		if (x < 32 && x >= 0) {
			Markersymbol = "lighthouse";
		} else if (x < 64 && x >= 32) {
			Markersymbol = "lighthouse";
		} else if (x < 96 && x >= 64) {
			Markersymbol = "lighthouse";
		} else if (x < 128 && x >= 96) {
			Markersymbol = "lighthouse";
		} else if (x < 160 && x >= 128) {
			Markersymbol = "danger";
		} else if (x < 192 && x >= 160) {
			Markersymbol = "danger";
		} else if (x < 224 && x >= 192) {
			Markersymbol = "danger";
		} else if (x < 256 && x >= 224) {
			Markersymbol = "danger";

		}

		if(battery <10) {
			Markersymbol = "cross";
		}
		return Markersymbol;

	}

}
