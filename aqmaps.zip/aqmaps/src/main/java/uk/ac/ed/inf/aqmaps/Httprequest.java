package uk.ac.ed.inf.aqmaps;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse.BodyHandlers;

/**
 * class for http request; 
 * @return response body
 * 
 */
public class Httprequest {
	public static String gethttp(String urlString) throws IOException, InterruptedException{
	// Create a new HttpClient with default settings.
	var client = HttpClient.newHttpClient();
	// HttpClient assumes that it is a GET request by default.
	var request = HttpRequest.newBuilder()
	.uri(URI.create(urlString))
	.build();
	// The response object is of class HttpResponse<String>
	var response = client.send(request, BodyHandlers.ofString());
	return response.body();
	}
}
