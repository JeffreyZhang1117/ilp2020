package uk.ac.ed.inf.aqmaps;

import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.mapbox.geojson.Feature;
import com.mapbox.geojson.FeatureCollection;
import com.mapbox.geojson.Point;
import com.mapbox.geojson.Polygon;

public class test {
	static int cloestIndex = 0;
	private static final double PATH_RANGE = 0.0003;

//	public static Point findClosestSensor(Point dronepoint, Map map) {
//		ArrayList<Double> distances = new ArrayList<Double>();
//		for (int i = 0; i < map.Locations.size(); i++) {
//			Point sensorPoint = map.Locations.get(i);
//			distances.add(euclidDist(dronepoint, sensorPoint));
//		}
//		cloestIndex = distances.indexOf(Collections.min(distances));
//		return map.Locations.get(cloestIndex);
//	}
	public static int findAngle2(Point dronepoint, Point sensor) {

		List<Integer> angles =new ArrayList<Integer>(36);
		for(int i =0; i < 37; i++) {
			angles.add(i * 10);
		}
		

		ArrayList<Double> distances = new ArrayList<Double>();
		for(int j =0; j < angles.size();j++) {
			Point nextdrone = Findpath.nextDrone(dronepoint, angles.get(j));
			distances.add(Findpath.euclidDist(nextdrone, sensor));
		}
		int cloestIndex = distances.indexOf(Collections.min(distances));
		return angles.get(cloestIndex);
	}

	public static String sensorInRange(Point dronepoint, Map map) {
		ArrayList<Double> distances = new ArrayList<Double>();
		for (int i = 0; i < map.getLocations().size(); i++) {
			Point sensorPoint = map.getLocations().get(i);
			distances.add(euclidDist(dronepoint, sensorPoint));
		}
		double clostestDistance = Collections.min(distances);
		System.out.print(clostestDistance);
		if (clostestDistance < 0.0002) {
			return map.getW3words().get(distances.indexOf(clostestDistance));
		} else {
			return "Not in range";
		}
	}

	static double euclidDist(Point x, Point y) {
		double sq1 = Math.pow(x.latitude() - y.latitude(), 2);
		double sq2 = Math.pow(x.longitude() - y.longitude(), 2);
		return Math.sqrt(sq1 + sq2);
	}

	public static boolean PointInrange(Point drone1,Point drone2) {
		if(euclidDist(drone1,drone2) < 0.0002) {
			return true;
		}else {
			return false;
		}
	}


	public static int findAngle(Point dronepoint, Point sensor) {
		double x1 = dronepoint.longitude();
		double y1 = dronepoint.latitude();
		double x2 = sensor.longitude();
		double y2 = sensor.latitude();
		double theta = Math.toDegrees(Math.atan2((y2 - y1), (x2 - x1)));
		double angle = 0.0;
		if (theta < 0) {
			angle = theta + 360;
		} else {
			angle = theta;
		}
		return (int) (Math.round(angle / 10.0) * 10);
	}

	public static Point nextDrone(Point dronepoint, int angle) {
		double lng = dronepoint.longitude() + (PATH_RANGE * Math.cos(Math.toRadians(angle)));
		double lat = dronepoint.latitude() + (PATH_RANGE * Math.sin(Math.toRadians(angle)));
		Point newpoint = Point.fromLngLat(lng, lat);
		return newpoint;
	}
//	public static ArrayList<String[]> findpathMix(int num, Point startpoint, Map map) {	
//		double dronelat = startpoint.latitude();
//		double dronelng = startpoint.longitude();
//		Point dronepoint = Point.fromLngLat(dronelng, dronelat);
//        ArrayList<String[]> flightpath = new ArrayList<String[]>();
//       
//		while (!map.Locations.isEmpty()) {
//				String[] flightinf = new String[7];
//				if(num > 150) {
//					break;
//				}
//				flightinf[0] = "" + num;
//				flightinf[1] = "" + dronelng;
//				flightinf[2] = "" + dronelat;
//				Point closetsensor = Findpath.findClosestSensor(dronepoint, map);
//				
//				int angle =0;
//				int angle1 = Position.findAngleMinus(dronepoint, closetsensor);
//				int angle2 = Position.findAnglePlus(dronepoint, closetsensor);
//				
//				Point nextdrone1 = Findpath.nextDrone(dronepoint, angle1);
//				Point nextdrone2 = Findpath.nextDrone(dronepoint, angle2);
//				
//				if (nextdrone1 == nextdrone2) {
//					angle = angle1;
//					dronelat = nextdrone1.latitude();
//					dronelng = nextdrone1.longitude();
//					dronepoint = Point.fromLngLat(dronelng, dronelat);
//				}else {
//					int pathminus = Findpath.TwoPointFlyMinus(1, dronepoint, closetsensor).size();
//					int pathplus =  Findpath.TwoPointFlyPlus(1, dronepoint, closetsensor).size();
//					if (pathminus <= pathplus) {
//						angle = angle1;
//						dronelat = nextdrone1.latitude();
//						dronelng = nextdrone1.longitude();
//						dronepoint = Point.fromLngLat(dronelng, dronelat);
//					}else {
//						angle = angle2;
//						dronelat = nextdrone2.latitude();
//						dronelng = nextdrone2.longitude();
//						dronepoint = Point.fromLngLat(dronelng, dronelat);
//					}
//				}
//                 
//				flightinf[3] = "" + angle;
//				flightinf[4] = "" + dronelng;
//				flightinf[5] = "" + dronelat;
//
//				if (PointInrange(dronepoint, closetsensor)) {
//					int index = map.Locations.indexOf(closetsensor);
//				    String w3word = map.w3words.get(index);
//				    flightinf[6] = "" + w3word;
//					map.Locations.remove(Findpath.cloestIndex);
//					map.w3words.remove(Findpath.cloestIndex);				    
//				}else {
//				
//					flightinf[6] = "" + "Null";
//				}
//				
//				flightpath.add(flightinf);
//				num++;
//		}
//		return flightpath;
//		
//	}
//	
//
	public static void main(String args[]) throws Exception{
		String date = args[0];
		String month = args[1];
		String year = args[2];
		String latitude = args[3];
		String longitude = args[4];
		String seed_no = args[5];
		String port = args[6];
		
		String air_quality_data_jsonURL = "http://localhost:" + port + "/maps/" + year + "/" + month + "/" + date
				+ "/air-quality-data.json";

		double longitude1 = Double.parseDouble(longitude);
		double latitude1 = Double.parseDouble(latitude);
		Point startPoint = Point.fromLngLat(longitude1, latitude1);
		Map map1 = new Map(air_quality_data_jsonURL,port);
		
		
		Point x = Findpath.findClosestSensor(startPoint, map1);
		System.out.println(x);
		int angel =  findAngle2(startPoint, x);
		System.out.println(angel);
		Point y = nextDrone(startPoint, angel);
		System.out.println(y);
		String w3word = sensorInRange(y, map1);
		System.out.println(w3word);
		map1.getLocations().remove(cloestIndex);
//		
		String a  = "";
		double b = x.latitude();
		double c = x.longitude();
		
		a = a + String.valueOf(b) + ","+  String.valueOf(c)+"\n" ;
		String d = "aaaaaa";
		ArrayList<String> a1 = new ArrayList<>();
		a1.add(a);
		a1.add(d);
		System.out.println(a1);
		System.out.print(c);


    }

}
