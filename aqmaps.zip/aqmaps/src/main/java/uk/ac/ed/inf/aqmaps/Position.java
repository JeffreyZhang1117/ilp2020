package uk.ac.ed.inf.aqmaps;

import java.util.ArrayList;
import java.util.List;


import com.mapbox.geojson.Point;

public class Position {
	

	/**
	 * This class to calcuate two type angles of each drone move and check the
	 * confinment area for each move.
	 * 
	 */
	
	
	/** 
	 * using private and static to keep top,bot,left,right would not be changed. 
	 * This can avoid duplicated calculation in every movement.
	 */
	
    private  final static double TOP = 55.946233;
    private  final static double BOT = 55.942617;
    private  final static double LEFT = -3.192473;
    private  final static double RIGHT = -3.184319;
	static List<Point> passbyPoint = new ArrayList<Point>();

	
	
	/**
	 *  check whether nextdrone positon located in confinement area.
	 *  @param nextdrone - the location of next drone movement.
	 */
	
	public static boolean inArea(Point nextDrone) {
		double latitude = nextDrone.latitude();
		double longitude = nextDrone.longitude();
		  boolean bool = (latitude < TOP) && (latitude > BOT) && (longitude < RIGHT)
		    && (longitude > LEFT);
		  if (!bool) {
		   return false;
		  }
		  return true;
		 }
	
	/**
	 * find the first type of angle between two point. When drone face no fly zone,
	 * it will change angle by minus 10 degree until leave no fly zones, which mean
	 * drone will choose right hand side angle to leave no fly zones
	 * 
	 * @param dronepoint  - the location of current drone.
	 * @param targetpoint - the location of target point that drone want to reach.
	 * @return int angle - the angle between drone and target point.
	 */

	public static int findAngleMinus(Point dronepoint, Point targetpoint) {
		double x1 = dronepoint.longitude();
		double y1 = dronepoint.latitude();
		double x2 = targetpoint.longitude();
		double y2 = targetpoint.latitude();
		// find the angle between drone position and sensor
		double theta = Math.toDegrees(Math.atan2((y2-y1), (x2-x1)));
		double angle = 0.0;
		if (theta <0) {
			angle = theta + 360;
		}else {
			angle = theta;
		}
		int angleminus = (int)(Math.round(angle/10.0)*10);
		Point nextdrone = Findpath.nextDrone(dronepoint, angleminus);
		while(
			  !Noflyzone.checkInNoFlyZone1(dronepoint, nextdrone) || 
			  !Noflyzone.checkInNoFlyZone2(dronepoint, nextdrone) || 
			  !Noflyzone.checkInNoFlyZone3(dronepoint, nextdrone) || 
			  !Noflyzone.checkInNoFlyZone4(dronepoint, nextdrone) || 
			  !inArea(nextdrone) ||
			  passbyPoint.contains(nextdrone)
			  ) {
			// when drone face noflyzone, the angle will minus 10 degree until leave.
			  angleminus = angleminus-10;
			  if(angleminus == 0) {
				  angleminus = 360;
			  }
			  nextdrone = Findpath.nextDrone(dronepoint, angleminus);
		}
		passbyPoint.add(Findpath.nextDrone(dronepoint, angleminus));
		if(angleminus == 360) {
			angleminus = 0;
		}
		if (angleminus <0) {
			angleminus = angleminus + 360;
		}
		return angleminus;
	}
	
	/**
	 * find the second type of angle between two point. When drone face no fly zone,
	 * it will change angle by add 10 degree until leave no fly zones, which mean
	 * drone will choose left hand side angle to leave no fly zones
	 * 
	 * @param dronepoint  - the location of current drone.
	 * @param targetpoint - the location of target point that drone want to reach.
	 * @return int angle - the angle between drone and target point.
	 */
	
	public static int findAnglePlus(Point dronepoint, Point sensor) {
		double x1 = dronepoint.longitude();
		double y1 = dronepoint.latitude();
		double x2 = sensor.longitude();
		double y2 = sensor.latitude();
		double theta = Math.toDegrees(Math.atan2((y2-y1), (x2-x1)));
		double angle = 0.0;
		if (theta <0) {
			angle = theta + 360;
		}else {
			angle = theta;
		}
		int angleplus = (int)(Math.round(angle/10.0)*10);
		Point nextdrone = Findpath.nextDrone(dronepoint, angleplus);
		while(
			  !Noflyzone.checkInNoFlyZone1(dronepoint, nextdrone) || 
			  !Noflyzone.checkInNoFlyZone2(dronepoint, nextdrone) || 
			  !Noflyzone.checkInNoFlyZone3(dronepoint, nextdrone) || 
			  !Noflyzone.checkInNoFlyZone4(dronepoint, nextdrone)||
			  !inArea(nextdrone) ||
			  passbyPoint.contains(nextdrone)) {
			// when face noflyzone, the angle will add 10 until leave noflyzone.
			  angleplus = angleplus +10;
			  if(angleplus == 0) {
				  angleplus = 360;
			  }
			  nextdrone = Findpath.nextDrone(dronepoint, angleplus);
		}
		passbyPoint.add(Findpath.nextDrone(dronepoint, angleplus));
		if(angleplus == 360) {
			angleplus = 0;
		}
		if (angleplus <0) {
			angleplus = angleplus + 360;
		}
		return angleplus;
	}
	

}
