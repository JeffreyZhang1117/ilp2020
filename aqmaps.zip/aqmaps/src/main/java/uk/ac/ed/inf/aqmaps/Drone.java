package uk.ac.ed.inf.aqmaps;

import java.util.ArrayList;


import com.mapbox.geojson.Point;

    /**
    * A class to represent a drone searching the map and finding the best path for sensor reading.
    */

public class Drone {

	
	private ArrayList<String []> dronepath  = new ArrayList<>();
    
    /**
     * Constructor to create a new drone instance and sets the ArrayList of best dronepath .
	 * @param startpoint - the start point of drone
	 * @param map1 - map for first search algorithm
	 * @param map2 - map for second search algorithm
	 * @param map3 - map for third search algorithm
	 * 
	 */
    
	public Drone(Point startpoint,Map map) throws Exception{
		
		
		double dronelat = startpoint.latitude();
		double dronelng = startpoint.longitude();
		Point dronepoint = Point.fromLngLat(dronelng, dronelat);
		int num = 1 ;
		ArrayList<String[]> flightpath = new ArrayList<String[]>();
		
		// get the flightpath for searching all sensor
		ArrayList<String[]> findpathMix = Findpath.findpathMix(num, dronepoint, map);
		System.out.println(findpathMix.size());
        
        flightpath = findpathMix;
        double lastlng = Double.parseDouble(flightpath.get(flightpath.size()-1)[4]);
		double lastlat = Double.parseDouble(flightpath.get(flightpath.size()-1)[5]);
		Point lastpoint = Point.fromLngLat(lastlng, lastlat); 
		
		// get the flightpath for drone back to start
		ArrayList<String[]> backToStartPlus =  Findpath.TwoPointFlyPlus(flightpath.size()+1, lastpoint, startpoint);
		ArrayList<String[]> backToStartMinus = Findpath.TwoPointFlyMinus(flightpath.size()+1, lastpoint, startpoint);
		if(backToStartMinus.size() <= backToStartPlus.size()) {
			System.out.println("minus:" + backToStartMinus.size());
			System.out.println("add:" + backToStartPlus.size());
        	flightpath.addAll(backToStartMinus);
        }else {
        	flightpath.addAll(backToStartPlus);
        }
	    System.out.println(flightpath.size());
		
	    // return the flightpath of whole process
		this.setDronepath(flightpath);
	    	
	}

	public ArrayList<String []> getDronepath() {
		return dronepath;
	}

	public void setDronepath(ArrayList<String []> dronepath) {
		this.dronepath = dronepath;
	} 
	


}

