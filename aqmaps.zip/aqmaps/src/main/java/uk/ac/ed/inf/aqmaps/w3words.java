package uk.ac.ed.inf.aqmaps;



public class w3words {
	/**
	 * class of w3words include all informations of sensor's w3word
	 */
    private String country;
	private String nearestPlace;
	private Site square;
	private PointLngLat coordinates;
	private String words;
	private String language;
	private String map;
	
	public static class Site{
		PointLngLat southwest;
		PointLngLat northeast;
	}
	
	public static class PointLngLat{
		Double lat;
		Double lng;
	}

	public PointLngLat getCoordinates() {
		return coordinates;
	}

	public void setCoordinates(PointLngLat coordinates) {
		this.coordinates = coordinates;
	}

}
