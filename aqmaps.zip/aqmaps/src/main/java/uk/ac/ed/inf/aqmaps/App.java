package uk.ac.ed.inf.aqmaps;


import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.mapbox.geojson.Feature;
import com.mapbox.geojson.FeatureCollection;
import com.mapbox.geojson.Geometry;
import com.mapbox.geojson.LineString;
import com.mapbox.geojson.Point;


public class App {
	/**
	 * Read and parse all arguments from the input and pass them to three new Map class.
	 * @param args - input arguments
	 * output the best search path txt and geojson
	 */
	public static void main(String[] args) throws Exception {
		
		String date = args[0];
		String month = args[1];
		String year = args[2];
		String startlatitude = args[3];
		String startlongitude = args[4];
		String seed_no = args[5];
		String port = args[6];
         // create the url string
		String air_quality_data_jsonURL = "http://localhost:" + port + "/maps/" + year + "/" + month + "/" + date
				+ "/air-quality-data.json";
		// initial noflyzone and map
        Noflyzone test = new Noflyzone(port);
		Map map1 = new Map(air_quality_data_jsonURL,port);
   
	
		double startlat = Double.parseDouble(startlatitude);
		double startlng = Double.parseDouble(startlongitude);
		Point startpoint = Point.fromLngLat(startlng, startlat);
		
		//initial a drone object and get the drone flightpath
		Drone drone = new Drone(startpoint,map1);
		ArrayList<String[]> flightpath = drone.getDronepath();
		
		// add point into line feature
		ArrayList<Point> linePoints = new ArrayList<Point>();
		for (int i = 0; i < flightpath.size(); i++) {
			double lng = Double.parseDouble(flightpath.get(i)[1]);
			double lat = Double.parseDouble(flightpath.get(i)[2]);
            Point point = Point.fromLngLat(lng, lat);
			linePoints.add(point);
		}
	
		LineString line = LineString.fromLngLats(linePoints);
		Feature lineFeat = Feature.fromGeometry((Geometry) line);
		
		// put all features into listof feature
		List<Feature> listfeature = new ArrayList<Feature>();
		listfeature.add(lineFeat);
		listfeature.addAll(map1.getListfeature());
	
		// generate the feature collection
		FeatureCollection featurecollection;
		featurecollection = FeatureCollection.fromFeatures(listfeature);
		String output = featurecollection.toJson();
		
		// change ArrayList<String[]> into string
		String finaloutput = "";
		for(int i = 0; i < flightpath.size(); i++) {
			StringBuffer string = new StringBuffer();
			for(int j=0 ; j < flightpath.get(i).length ; j++) {
				if (flightpath.get(i)[j] != flightpath.get(i)[flightpath.get(i).length-1]) {
					string.append(flightpath.get(i)[j] + ",");
				}
				else {
					string.append(flightpath.get(i)[j] + "");
				}
			}
			finaloutput = finaloutput + string + "\n";
		}
	

		// file output .txt and .geojson
		FileWriter writer;
		try {
			writer = new FileWriter("readings-" + date + "-" + month + "-" + year + ".geojson");
			writer.write(output);
			writer.flush();
			writer.close();
			System.out.println("good game!");
			
		} catch (IOException ex) {
			ex.printStackTrace();
		}
		
		FileWriter writer1;
		try {
			writer1 = new FileWriter("flightpath-" + date + "-" + month + "-" + year + ".txt");
			writer1.write(finaloutput);
			writer1.flush();
			writer1.close();
			System.out.println(".txt");
			
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}		
	
}

