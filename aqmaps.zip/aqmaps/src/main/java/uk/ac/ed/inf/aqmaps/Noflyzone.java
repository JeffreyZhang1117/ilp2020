package uk.ac.ed.inf.aqmaps;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.mapbox.geojson.Feature;
import com.mapbox.geojson.FeatureCollection;
import com.mapbox.geojson.Point;
import com.mapbox.geojson.Polygon;


public class Noflyzone {

	private static double[] poly0lat;
	private static double[] poly0lng; 
	private static double[] poly1lat; 
	private static double[] poly1lng; 
	private static double[] poly2lat; 
	private static double[] poly2lng; 
	private static double[] poly3lat; 
	private static double[] poly3lng; 
	
	/**
	 * A class to represent the four no fly zone's coordinate, it include the point of
	 * each polygon.
	 */

	public Noflyzone(String port) throws IOException, InterruptedException {
		String noflyzoneURL = "http://localhost:" + port + "/buildings/no-fly-zones.geojson";
		String noflyzonemap = Httprequest.gethttp(noflyzoneURL);
		FeatureCollection fc = FeatureCollection.fromJson(noflyzonemap);
		ArrayList<Feature> listfeature = new ArrayList<>();
		ArrayList<Polygon> listPolygon = new ArrayList<>();
		listfeature = (ArrayList<Feature>) fc.features();
		for (Feature f : listfeature) {
			listPolygon.add((Polygon) f.geometry());
		}


	
		List<Point> listpoint0 = listPolygon.get(0).coordinates().get(0);
		List<Point> listpoint1 = listPolygon.get(1).coordinates().get(0);
		List<Point> listpoint2 = listPolygon.get(2).coordinates().get(0);
		List<Point> listpoint3 = listPolygon.get(3).coordinates().get(0);
		
		double[] poly0lat = new double[listpoint0.size()];
		double[] poly0lng = new double[listpoint0.size()];
		double[] poly1lat = new double[listpoint1.size()];
		double[] poly1lng = new double[listpoint1.size()];
		double[] poly2lat = new double[listpoint2.size()];
		double[] poly2lng = new double[listpoint2.size()];
		double[] poly3lat = new double[listpoint3.size()];
		double[] poly3lng = new double[listpoint3.size()];

		int i = 0;
		for (Point p0 : listpoint0) {
			poly0lat[i] = p0.latitude();
			poly0lng[i] = p0.longitude();
			i++;
		}

		int j = 0;
		for (Point p1 : listpoint1) {
			poly1lat[j] = p1.latitude();
			poly1lng[j] = p1.longitude();
			j++;
		}
		int k = 0;
		for (Point p2 : listpoint2) {
			poly2lat[k] = p2.latitude();
			poly2lng[k] = p2.longitude();
			k++;
		}
		int z = 0;
		for (Point p3 : listpoint3) {
			poly3lat[z] = p3.latitude();
			poly3lng[z] = p3.longitude();
			z++;
		}
		
		Noflyzone.poly0lat = poly0lat;
		Noflyzone.poly0lng = poly0lng;
		Noflyzone.poly1lat = poly1lat;
		Noflyzone.poly1lng = poly1lng;
		Noflyzone.poly2lat = poly2lat;
		Noflyzone.poly2lng = poly2lng;
	    Noflyzone.poly3lat = poly3lat;
	    Noflyzone.poly3lng = poly3lng;

	}
	/**
	 * four static function to check next position could be take or not in four no fly zones.
	 * @param start - the start point of drone 
	 * @param end   - the end point of drone
	 */
	public static boolean checkInNoFlyZone1(Point start, Point end) {
		return checkNotInNoFlyZones(start, end, poly0lat, poly0lng);
				}
	public static boolean checkInNoFlyZone2(Point start, Point end) {
		return checkNotInNoFlyZones(start, end, poly1lat, poly1lng);
				}
	public static boolean checkInNoFlyZone3(Point start, Point end) {
		return checkNotInNoFlyZones(start, end, poly2lat, poly2lng);
				}
	public static boolean checkInNoFlyZone4(Point start, Point end) {
		return checkNotInNoFlyZones(start, end, poly3lat,poly3lng);
				}
	
	/**
	 * static function to check next position could be take or not in four no fly
	 * zones. if next point locate in no fly zone, it return false, if next point
	 * not locate in , it return true.
	 * 
	 * @param start            - the start point of drone
	 * @param end              - the end point of drone
	 * @param polygonPoint_lat - list of noflyzone's latitude
	 * @param polygonPoint_lng - list of noflyzone's longitude
	 */

	private static boolean checkNotInNoFlyZones(Point start, Point end, double[] polygonPoint_lat,
			double[] polygonPoint_lng) {
		for (int i = 0; i < polygonPoint_lat.length - 1; i++) {
			if (isIntersect(start.latitude(), start.longitude(), end.latitude(), end.longitude(), polygonPoint_lat[i],
					polygonPoint_lng[i], polygonPoint_lat[i + 1], polygonPoint_lng[i + 1])) {
				return false;
			}
		}
		return true;
	}

	/**
	 * static function to check whether the line of start point and end point is intersect with the boundaries of polygon
	 * @param l1x1   - drone start point's latitude
	 * @param l1y1   - drone start point's longitude
	 * @param l1x2   - drone end point's latitude
	 * @param l1y2   - drone end point's longitude
	 * @param l2x1   - polygon start point's latitude
	 * @param l2y1   - polygon tart point's longitude
	 * @param l2x2   - polygon end point's latitude
	 * @param l2y2   - drone end point's longitude
	 */
	private static boolean isIntersect(double l1x1, double l1y1, double l1x2, double l1y2, double l2x1, double l2y1,
			double l2x2, double l2y2) {
		if (Math.max(l1x1, l1x2) < Math.min(l2x1, l2x2) || Math.max(l1y1, l1y2) < Math.min(l2y1, l2y2)
				|| Math.max(l2x1, l2x2) < Math.min(l1x1, l1x2) || Math.max(l2y1, l2y2) < Math.min(l1y1, l1y2)) {
			return false;
		}
		if ((((l1x1 - l2x1) * (l2y2 - l2y1) - (l1y1 - l2y1) * (l2x2 - l2x1))
				* ((l1x2 - l2x1) * (l2y2 - l2y1) - (l1y2 - l2y1) * (l2x2 - l2x1))) > 0
				|| (((l2x1 - l1x1) * (l1y2 - l1y1) - (l2y1 - l1y1) * (l1x2 - l1x1))
						* ((l2x2 - l1x1) * (l1y2 - l1y1) - (l2y2 - l1y1) * (l1x2 - l1x1))) > 0) {
			return false;
		}
		return true;
	}



}
