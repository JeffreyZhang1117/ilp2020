package uk.ac.ed.inf.aqmaps;

import java.util.ArrayList;
import java.util.Collections;

import com.mapbox.geojson.Point;


public class Findpath {
	private static final double PATH_RANGE = 0.0003;
	private static final double CLOST_RANGE = 0.0002;
	private static  int cloestIndex = 0;
	
	
	/**
	 * This static method will calculate the Euclidean Distance between two positions
	 * @param x The first position
	 * @param y The second position
	 * @return The Euclidean Distance between x and y.
	 */
	static double euclidDist(Point x, Point y) {
		double sq1 = Math.pow(x.latitude() - y.latitude(), 2);
		double sq2 = Math.pow(x.longitude() - y.longitude(), 2);
		return Math.sqrt(sq1 + sq2);
	}
   
	/**
    * This static method will calculate the nextpoint of drone to go
    * @param dronepoint is the current location of drone
    * @param angle is the angle between current location and next planed location 
    * @return Location of next drone include longitude and latitude
    */

	public static Point nextDrone(Point dronepoint, int angle) {
		double lng = dronepoint.longitude() + (PATH_RANGE * Math.cos(Math.toRadians(angle)));
		double lat = dronepoint.latitude() + (PATH_RANGE * Math.sin(Math.toRadians(angle)));
		Point newpoint = Point.fromLngLat(lng, lat);
		return newpoint;
	}
	
	/**
	 * This static method will find the closet sensor for current drone
	 * using the greedy strategy,find minimum euciliden distance sensor
	 * 
	 * @param dronepoint is the current location of drone
	 * @param map        is the map of which day we want to know the flightpath. it
	 *                   include the seneor list.
	 * @return Location of closetSensor in map
	 */
	public static Point findClosestSensor(Point dronepoint, Map map) {
		ArrayList<Double> distances = new ArrayList<Double>();
		for (int i = 0; i < map.getLocations().size(); i++) {
			Point sensorPoint = map.getLocations().get(i);
			distances.add(euclidDist(dronepoint, sensorPoint));
		}
		cloestIndex = distances.indexOf(Collections.min(distances));

		return map.getLocations().get(cloestIndex);
	
	}
	
	/**
	 * This static method will check whether two location is already in drone range
	 * 
	 * @param drone1     is the current location of drone
	 * @param drone2     is the location of closestsensor you find or startpoint
	 * @return Boolean
	 */
	
	public static boolean PointInrange(Point drone1,Point drone2) {
		if(euclidDist(drone1,drone2) < CLOST_RANGE) {
			return true;
		}else {
			return false;
		}
	}

	/**
	 * This static method is my find path algorithm. It will find the drone
	 * flight path about sensorlist, when drone face the noflyzone, it will compare
	 * the path required of flying toward left hand side to avoid noflyzone and
	 * flying toward right hand size, then choose the minimum path to fly pass zone.
	 * 
	 * @param num   is count number of flightnum
	 * @param point is the startpoint of drone
	 * @param map   is the map of which day we want to know the flightpath
	 * @return ArrayList<String[]> ,which include all information of drone flight path.
	 *        
	 */

	public static ArrayList<String[]> findpathMix(int num, Point startpoint, Map map) {	
		double dronelat = startpoint.latitude();
		double dronelng = startpoint.longitude();
		Point dronepoint = Point.fromLngLat(dronelng, dronelat);
        ArrayList<String[]> flightpath = new ArrayList<String[]>();
       
		while (!map.getLocations().isEmpty()) {
				String[] flightinf = new String[7];
				if(num > 150) {
					break;
				}
				flightinf[0] = "" + num;
				flightinf[1] = "" + dronelng;
				flightinf[2] = "" + dronelat;
				Point closetsensor = Findpath.findClosestSensor(dronepoint, map);
				
				// compare two probability of noflyzone, chooch best option
				int angle =0;
				int angle1 = Position.findAngleMinus(dronepoint, closetsensor);
				int angle2 = Position.findAnglePlus(dronepoint, closetsensor);
				
				Point nextdrone1 = Findpath.nextDrone(dronepoint, angle1);
				Point nextdrone2 = Findpath.nextDrone(dronepoint, angle2);
				
				if (nextdrone1 == nextdrone2) {
					angle = angle1;
					dronelat = nextdrone1.latitude();
					dronelng = nextdrone1.longitude();
					dronepoint = Point.fromLngLat(dronelng, dronelat);
				}else {
					// calculate required steps to avoid nofly zone.
					int pathminus = Findpath.TwoPointFlyMinus(1, dronepoint, closetsensor).size();
					int pathplus =  Findpath.TwoPointFlyPlus(1, dronepoint, closetsensor).size();
					if (pathminus <= pathplus) {
						angle = angle1;
						dronelat = nextdrone1.latitude();
						dronelng = nextdrone1.longitude();
						dronepoint = Point.fromLngLat(dronelng, dronelat);
					}else {
						angle = angle2;
						dronelat = nextdrone2.latitude();
						dronelng = nextdrone2.longitude();
						dronepoint = Point.fromLngLat(dronelng, dronelat);
					}
				}
                 
				flightinf[3] = "" + angle;
				flightinf[4] = "" + dronelng;
				flightinf[5] = "" + dronelat;

				if (PointInrange(dronepoint, closetsensor)) {
					int index = map.getLocations().indexOf(closetsensor);
				    String w3word = map.getW3words().get(index);
				    flightinf[6] = "" + w3word;
					map.getLocations().remove(Findpath.cloestIndex);
					map.getW3words().remove(Findpath.cloestIndex);				    
				}else {
				
					flightinf[6] = "" + "null";
				}
				
				flightpath.add(flightinf);
				num++;
		}
		return flightpath;
		
	}


	
	
	//
	/**
	 * This static method is find the path between two specific location.
	 * When it face no fly zone, it will choose right hand angle to fly and keep searching.
	 
	 * 
	 * @param num   is count number of flightnum
	 * @param point is the endpoint of drone
	 * @param startpoint is the start point of drone.
	 * @return ArrayList<String[]> ,which include all information of drone flight
	 *         path.
	 * 
	 */

	//
	public static ArrayList<String[]> TwoPointFlyMinus(int num, Point EndPoint, Point StartPoint) {
		ArrayList<String[]> flightback = new ArrayList<String[]>();

		while (!PointInrange(EndPoint, StartPoint)) {
			    if(num >= 150) {
				break;
			    }
				String[] flightinf = new String[7];
				flightinf[0] = "" + num;
				flightinf[1] = "" + EndPoint.longitude();
				flightinf[2] = "" + EndPoint.latitude();

				int angle = Position.findAngleMinus(EndPoint, StartPoint);
				flightinf[3] = "" + angle;

				Point nextdrone = Findpath.nextDrone(EndPoint, angle);
				double dronelat = nextdrone.latitude();
				double dronelng = nextdrone.longitude();
				EndPoint = com.mapbox.geojson.Point.fromLngLat(dronelng, dronelat);
				flightinf[4] = "" + nextdrone.longitude();
				flightinf[5] = "" + nextdrone.latitude();
				flightinf[6] = "null";
				flightback.add(flightinf);
		        num ++;
		}
		return flightback;
	}
	/**
	 * This static method is find the path between two specific location.
	 * When it face no fly zone, it will choose left hand angle to fly and keep searching.
	 
	 * 
	 * @param num   is count number of flightnum
	 * @param point is the endpoint of drone
	 * @param startpoint is the start point of drone.
	 * @return ArrayList<String[]> ,which include all information of drone flight
	 *         path.
	 * 
	 */
	public static ArrayList<String[]> TwoPointFlyPlus(int num, Point Point, Point StartPoint) {
		ArrayList<String[]> flightback = new ArrayList<String[]>();

		while (!PointInrange(Point, StartPoint)) {
			    if(num >= 150) {
				break;
			    }
				String[] flightinf = new String[7];
				flightinf[0] = "" + num;
				flightinf[1] = "" + Point.longitude();
				flightinf[2] = "" + Point.latitude();

				int angle = Position.findAnglePlus(Point, StartPoint);
				flightinf[3] = "" + angle;

				Point nextdrone = Findpath.nextDrone(Point, angle);
				double dronelat = nextdrone.latitude();
				double dronelng = nextdrone.longitude();
				Point = com.mapbox.geojson.Point.fromLngLat(dronelng, dronelat);
				flightinf[4] = "" + nextdrone.longitude();
				flightinf[5] = "" + nextdrone.latitude();
				flightinf[6] = "null";
				flightback.add(flightinf);
		        num ++;
		}
		return flightback;
	}


}
