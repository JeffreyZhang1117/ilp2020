package uk.ac.ed.inf.aqmaps;

import java.util.ArrayList;
import java.util.List;

import java.lang.reflect.Type;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.mapbox.geojson.Feature;
import com.mapbox.geojson.FeatureCollection;

import com.mapbox.geojson.Point;

public class Map {
	
	/**
	 * A class to represent the map of specific day, it include the location of
	 * sensors, the battery information of sensors, the w3words of sensors and 
	 * list of feature of sensors.
	 */

	private List<Point> Locations = new ArrayList<>();
	private List<Double> battery = new ArrayList<>();
	private List<String> w3words = new ArrayList<>();
	private List<Feature> listfeature = new ArrayList<Feature>();

	FeatureCollection featurecollection;

	
	public Map(String mapstring,String port) throws Exception {
	
		String map = Httprequest.gethttp(mapstring);
		
		Type SensorsTypeList = new TypeToken<ArrayList<Sensor>>() {
		}.getType();
		ArrayList<Sensor> Sensors = new Gson().fromJson(map, SensorsTypeList);
    
		
		for (Sensor sensor : Sensors) {
			sensor.getlatilong(port);
			sensor.getRGB();
			sensor.getMarker();
			this.getListfeature().add(sensor.SensortoFeature());
			this.getLocations().add(sensor.point);
			this.battery.add(sensor.getBattery());
			this.getW3words().add(sensor.getLocation());

		}
		
     }


	public List<Feature> getListfeature() {
		return listfeature;
	}


	public void setListfeature(List<Feature> listfeature) {
		this.listfeature = listfeature;
	}


	public List<Point> getLocations() {
		return Locations;
	}


	public void setLocations(List<Point> locations) {
		Locations = locations;
	}


	public List<String> getW3words() {
		return w3words;
	}


	public void setW3words(List<String> w3words) {
		this.w3words = w3words;
	}
}
