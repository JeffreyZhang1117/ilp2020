package uk.ac.ed.inf.aqmaps;


import com.google.gson.Gson;
import com.mapbox.geojson.Feature;
import com.mapbox.geojson.Point;

public class Sensor {
	/**
	 *  a class include all informations of each sensor
	 *  Get the RGBstring and makersymbol for geojson.
	 */
	
	 private String location;
	 private double battery;
	 private String reading;
	 
	 private String RGBstring;
	 private String Markersymbol;
	 Point point;
	 
	 public void getlatilong(String port) throws Exception{
		 String[] splitwords = getLocation().split("\\.");
		 String httpstring = "http://localhost:" + port +"/words/" + splitwords[0] + "/" + splitwords[1] + "/" + splitwords[2] + "/details.json";
		 String  http = Httprequest.gethttp(httpstring);
		 w3words w3words = new Gson().fromJson(http, w3words.class);
		 this.point = Point.fromLngLat(w3words.getCoordinates().lng, w3words.getCoordinates().lat);
	 }
	 public void getRGB() throws Exception{
              RGBstring = SetRGBString.SetRGBStrings(reading,getBattery());		 
	 }
	 public void getMarker() throws Exception{
              Markersymbol = SetMarkerSymbol.Setmarkersymbol(reading,getBattery());	 
     }
	 public Feature SensortoFeature() {
		 Feature f = Feature.fromGeometry(point);
		 f.addStringProperty("location", getLocation());
		 f.addStringProperty("rgb-string", RGBstring);
		 f.addStringProperty("marker-color", RGBstring);
		 f.addStringProperty("marker-symbol", Markersymbol);
		 return f;
		 
	 }
	public double getBattery() {
		return battery;
	}
	public void setBattery(double battery) {
		this.battery = battery;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	 

}
