package uk.ac.ed.inf.aqmaps;

public class SetRGBString {
  /**
   * the function to get RGBstring
   * @param reading
   * @param battery
   * @return RGBstring
   */
	public static  String SetRGBStrings(String reading,Double battery) {
		String RGB = "#aaaaaa"; // no symbol

		if (reading.equals("NaN") || reading.equals("null")) {
			RGB = "#000000";
			return RGB;
		}
		Double x = Double.parseDouble(reading);
		if (x < 32 && x >= 0) {
			RGB = "#00ff00";

		} else if (x < 64 && x >= 32) {
			RGB = "#40ff00";

		} else if (x < 96 && x >= 64) {
			RGB = "#80ff00";

		} else if (x < 128 && x >= 96) {
			RGB = "#c0ff00";

		} else if (x < 160 && x >= 128) {
			RGB = "#ffc000";

		} else if (x < 192 && x >= 160) {
			RGB = "#ff8000";

		} else if (x < 224 && x >= 192) {
			RGB = "#ff4000";

		} else if (x < 256 && x >= 224) {
			RGB = "#ff0000";

		}
	
		if(battery<10) {
			RGB = "#000000";
		}

		return RGB;
	}

}
