package uk.ac.ed.inf.aqmaps;

import java.util.ArrayList;
import java.util.List;

import com.mapbox.geojson.Feature;
import com.mapbox.geojson.FeatureCollection;
import com.mapbox.geojson.Point;
import com.mapbox.geojson.Polygon;

public class xiaohan {
	double[] lati1;
	double[] lati2;
	double[] lati3;
	double[] lati4;
	double[] long1;
	double[] long2;
	double[] long3;
	double[] long4;

	public xiaohan() throws Exception {
		String http = Httprequest.gethttp("http://localhost/buildings/no-fly-zones.geojson");
		FeatureCollection fc = FeatureCollection.fromJson(http);
		List<Feature> featurelist = new ArrayList<>();
		List<Polygon> polygonlist = new ArrayList<>();
		featurelist = fc.features();
		for (Feature feature : featurelist) {
			polygonlist.add((Polygon) feature.geometry());
		}
		List<List<Point>> pointlistlist1 = new ArrayList<>();
		List<List<Point>> pointlistlist2 = new ArrayList<>();
		List<List<Point>> pointlistlist3 = new ArrayList<>();
		List<List<Point>> pointlistlist4 = new ArrayList<>();
		pointlistlist1 = polygonlist.get(0).coordinates();
		pointlistlist2 = polygonlist.get(1).coordinates();
		pointlistlist3 = polygonlist.get(2).coordinates();
		pointlistlist4 = polygonlist.get(3).coordinates();
		List<Point> pointlist1 = new ArrayList<>();
		pointlist1 = pointlistlist1.get(0);
		List<Point> pointlist2 = new ArrayList<>();
		pointlist2 = pointlistlist2.get(0);
		List<Point> pointlist3 = new ArrayList<>();
		pointlist3 = pointlistlist3.get(0);
		List<Point> pointlist4 = new ArrayList<>();
		pointlist4 = pointlistlist4.get(0);
		double[] lati1 = new double[pointlist1.size()];
		double[] long1 = new double[pointlist1.size()];
		int i = 0;
		for (Point point : pointlist1) {
			lati1[i] = point.latitude();
			long1[i] = point.longitude();
			i = i + 1;
		}
		double[] lati2 = new double[pointlist2.size()];
		double[] long2 = new double[pointlist2.size()];
		i = 0;
		for (Point point : pointlist2) {
			lati2[i] = point.latitude();
			long2[i] = point.longitude();
			i = i + 1;
		}
		double[] lati3 = new double[pointlist3.size()];
		double[] long3 = new double[pointlist3.size()];
		i = 0;
		for (Point point : pointlist3) {
			lati3[i] = point.latitude();
			long3[i] = point.longitude();
			i = i + 1;
		}
		List<Double> lati41 = new ArrayList<>();
		List<Double> long41 = new ArrayList<>();
		i = 0;
		for (Point point : pointlist4) {
			lati41.add(point.latitude());
			long41.add(point.longitude());
			i = i + 1;
		}
		lati41.remove(4);
		lati41.remove(4);
		long41.remove(3);
		long41.remove(3);
		double[] lati4 = new double[lati41.size()];
		for(int i1 = 0;i1<lati41.size();i1++){
		    lati4[i1] = lati41.get(i1);
		}
		double[] long4 = new double[long41.size()];
		for(int i1 = 0;i1<long41.size();i1++){
		    long4[i1] = long41.get(i1);
		}
		this.lati1 = lati1;
		this.lati2 = lati2;
		this.lati3 = lati3;
		this.lati4 = lati4;
		this.long1 = long1;
		this.long2 = long2;
		this.long3 = long3;
		this.long4 = long4;
	}

	public boolean checkNoFlyZones(Point start, Point end) {
		return checkNotInNoFlyZones(start, end, lati1, long1) && checkNotInNoFlyZones(start, end, lati2, long2)
				&& checkNotInNoFlyZones(start, end, lati3, long3) && checkNotInNoFlyZones(start, end, lati4, long4);
	}

	public boolean checkNotInNoFlyZones(Point start, Point end, double[] polygonPoint_lat, double[] polygonPoint_lng) {
		for (int i = 0; i < polygonPoint_lat.length - 1; i++) {
			if (isIntersect(start.latitude(), start.longitude(), end.latitude(), end.longitude(), polygonPoint_lat[i],
					polygonPoint_lng[i], polygonPoint_lat[i + 1], polygonPoint_lng[i + 1])) {
				return false;
			}
		}
		return true;
	}

	public boolean isIntersect(double px1,double py1,double px2,double py2,double px3,double py3,double px4,double py4)//p1-p2 is or not intersect with p3-p4
    {
        boolean flag = false;
        double d = (px2-px1)*(py4-py3) - (py2-py1)*(px4-px3);
        if(d!=0)
        {
            double r = ((py1-py3)*(px4-px3)-(px1-px3)*(py4-py3))/d;
            double s = ((py1-py3)*(px2-px1)-(px1-px3)*(py2-py1))/d;
            if((r>=0) && (r <= 1) && (s >=0) && (s<=1))
            {
                flag = true;
            }
        }
        return flag;
    }
}
